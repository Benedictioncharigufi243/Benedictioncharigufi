from dotenv import load_dotenv
load_dotenv()

import logging
import os
import hashlib
import io
import time
import uuid
from collections import OrderedDict, defaultdict, deque
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List

import bcrypt
import jwt
import requests
import json
from emergentintegrations.llm.chat import LlmChat, UserMessage
from fastapi import APIRouter, Depends, FastAPI, File, HTTPException, Request, Response, UploadFile
from fastapi.responses import StreamingResponse
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, Field
from PIL import Image, ImageOps
from starlette.concurrency import run_in_threadpool
from starlette.middleware.gzip import GZipMiddleware
from starlette.middleware.cors import CORSMiddleware

mongo_url = os.environ["MONGO_URL"]
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ["DB_NAME"]]

app = FastAPI()
api_router = APIRouter(prefix="/api")

JWT_ALGORITHM = "HS256"

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# ---------- Object storage ----------
STORAGE_BASE = (os.environ.get("INTEGRATION_PROXY_URL") or "").strip() or "https://integrations.emergentagent.com"
STORAGE_URL = STORAGE_BASE.rstrip("/") + "/objstore/api/v1/storage"
APP_NAME = "exauce-site"
storage_key = None


def init_storage(force: bool = False):
    global storage_key
    if storage_key and not force:
        return storage_key
    resp = requests.post(f"{STORAGE_URL}/init", json={"emergent_key": os.environ.get("EMERGENT_LLM_KEY")}, timeout=30)
    resp.raise_for_status()
    storage_key = resp.json()["storage_key"]
    return storage_key


def put_object(path: str, data: bytes, content_type: str) -> dict:
    key = init_storage()
    resp = requests.put(
        f"{STORAGE_URL}/objects/{path}",
        headers={"X-Storage-Key": key, "Content-Type": content_type},
        data=data,
        timeout=120,
    )
    resp.raise_for_status()
    return resp.json()


def get_object(path: str):
    key = init_storage()
    resp = requests.get(f"{STORAGE_URL}/objects/{path}", headers={"X-Storage-Key": key}, timeout=60)
    resp.raise_for_status()
    return resp.content, resp.headers.get("Content-Type", "application/octet-stream")


# ---------- Cache, limites, ETag ----------
_CACHE: Dict[str, Any] = {}
CACHE_TTL = 60
HTTP_CC = "public, max-age=0, must-revalidate"


def _cache_get(key: str):
    hit = _CACHE.get(key)
    return hit[1] if hit and time.time() - hit[0] < CACHE_TTL else None


def _cache_set(key: str, value):
    _CACHE[key] = (time.time(), value)
    return value


def _conditional_json(request: Request, response: Response, payload):
    """ETag : le navigateur recoit un 304 vide si rien n'a change."""
    body = json.dumps(payload, sort_keys=True, default=str)
    etag = '"' + hashlib.md5(body.encode()).hexdigest() + '"'
    if request.headers.get("if-none-match") == etag:
        return Response(status_code=304, headers={"ETag": etag, "Cache-Control": HTTP_CC})
    response.headers["ETag"] = etag
    response.headers["Cache-Control"] = HTTP_CC
    return payload


_RATE: Dict[str, deque] = defaultdict(deque)


def rate_limit(request: Request, bucket: str, limit: int, window: int):
    fwd = request.headers.get("x-forwarded-for", "").split(",")[0].strip()
    ip = fwd or (request.client.host if request.client else "?")
    now = time.time()
    q = _RATE[f"{bucket}:{ip}"]
    while q and now - q[0] > window:
        q.popleft()
    if len(q) >= limit:
        raise HTTPException(status_code=429, detail="Trop de messages, reessayez dans quelques minutes.")
    q.append(now)
    if len(_RATE) > 5000:
        for k in [k for k, v in _RATE.items() if not v]:
            _RATE.pop(k, None)


# ---------- Auth ----------
def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))


def get_jwt_secret() -> str:
    return os.environ["JWT_SECRET"]


def create_access_token(user_id: str, email: str) -> str:
    payload = {"sub": user_id, "email": email, "exp": datetime.now(timezone.utc) + timedelta(minutes=15), "type": "access"}
    return jwt.encode(payload, get_jwt_secret(), algorithm=JWT_ALGORITHM)


def create_refresh_token(user_id: str) -> str:
    payload = {"sub": user_id, "exp": datetime.now(timezone.utc) + timedelta(days=7), "type": "refresh"}
    return jwt.encode(payload, get_jwt_secret(), algorithm=JWT_ALGORITHM)


def _cookie_options(request: Request) -> dict:
    # Secure cookies are required for SameSite=None, but they do not work over
    # plain HTTP during local development.
    is_secure = request.url.scheme == "https" or os.environ.get("COOKIE_SECURE", "").lower() == "true"
    return {
        "httponly": True,
        "secure": is_secure,
        "samesite": "none" if is_secure else "lax",
        "path": "/",
    }


def set_auth_cookies(response: Response, request: Request, user_id: str, email: str):
    options = _cookie_options(request)
    response.set_cookie("access_token", create_access_token(user_id, email), max_age=900, **options)
    response.set_cookie("refresh_token", create_refresh_token(user_id), max_age=604800, **options)


async def get_current_user(request: Request) -> dict:
    token = request.cookies.get("access_token")
    if not token:
        auth_header = request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            token = auth_header[7:]
    if not token:
        raise HTTPException(status_code=401, detail="Not authenticated")
    try:
        payload = jwt.decode(token, get_jwt_secret(), algorithms=[JWT_ALGORITHM])
        if payload.get("type") != "access":
            raise HTTPException(status_code=401, detail="Invalid token type")
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")
    user = await db.users.find_one({"_id": payload["sub"]})
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    user.pop("password_hash", None)
    return user


class LoginInput(BaseModel):
    email: str
    password: str


@api_router.post("/auth/login")
async def login(input: LoginInput, request: Request, response: Response):
    email = input.email.lower().strip()
    identifier = f"{request.client.host}:{email}"
    attempts = await db.login_attempts.find_one({"identifier": identifier})
    if attempts and attempts.get("count", 0) >= 5:
        locked_until = attempts.get("locked_until")
        if locked_until and datetime.fromisoformat(locked_until) > datetime.now(timezone.utc):
            raise HTTPException(status_code=429, detail="Trop de tentatives. Reessayez dans 15 minutes.")
    user = await db.users.find_one({"email": email})
    if not user or not verify_password(input.password, user["password_hash"]):
        count = (attempts.get("count", 0) if attempts else 0) + 1
        update: Dict[str, Any] = {"identifier": identifier, "count": count}
        if count >= 5:
            update["locked_until"] = (datetime.now(timezone.utc) + timedelta(minutes=15)).isoformat()
        await db.login_attempts.update_one({"identifier": identifier}, {"$set": update}, upsert=True)
        raise HTTPException(status_code=401, detail="Email ou mot de passe incorrect")
    await db.login_attempts.delete_one({"identifier": identifier})
    set_auth_cookies(response, request, user["_id"], email)
    return {"id": user["_id"], "email": email, "name": user.get("name", ""), "role": user.get("role", "admin")}


@api_router.post("/auth/logout")
async def logout(request: Request, response: Response):
    options = _cookie_options(request)
    response.delete_cookie("access_token", path=options["path"], secure=options["secure"], httponly=options["httponly"], samesite=options["samesite"])
    response.delete_cookie("refresh_token", path=options["path"], secure=options["secure"], httponly=options["httponly"], samesite=options["samesite"])
    return {"ok": True}


@api_router.get("/auth/me")
async def me(user: dict = Depends(get_current_user)):
    return {"id": user["_id"], "email": user["email"], "name": user.get("name", ""), "role": user.get("role", "admin")}


@api_router.post("/auth/refresh")
async def refresh(request: Request, response: Response):
    token = request.cookies.get("refresh_token")
    if not token:
        raise HTTPException(status_code=401, detail="Not authenticated")
    try:
        payload = jwt.decode(token, get_jwt_secret(), algorithms=[JWT_ALGORITHM])
        if payload.get("type") != "refresh":
            raise HTTPException(status_code=401, detail="Invalid token type")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")
    user = await db.users.find_one({"_id": payload["sub"]})
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    set_auth_cookies(response, request, user["_id"], user["email"])
    return {"ok": True}


# ---------- Content (acting profile) ----------
HERO_ACTOR = "https://images.unsplash.com/photo-1565665580796-7258b3823736?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA2OTV8MHwxfHNlYXJjaHw0fHxkcmFtYXRpYyUyMGJsYWNrJTIwbWFsZSUyMGFjdG9yJTIwcG9ydHJhaXR8ZW58MHx8fHwxNzkwNTc1NzY0fDA&ixlib=rb-4.1.0&q=85"
HERO_SCREENWRITER = "https://images.unsplash.com/photo-1612544409025-e1f6a56c1152?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDQ2MzR8MHwxfHNlYXJjaHwxfHxmaWxtJTIwc2V0JTIwYmVoaW5kJTIwc2NlbmVzJTIwZGFya3xlbnwwfHx8fDE3OTA1NzU3NjR8MA&ixlib=rb-4.1.0&q=85"
GALLERY_1 = "https://images.unsplash.com/photo-1518882570151-157128e78fa1?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA2OTV8MHwxfHNlYXJjaHwyfHxkcmFtYXRpYyUyMGJsYWNrJTIwbWFsZSUyMGFjdG9yJTIwcG9ydHJhaXR8ZW58MHx8fHwxNzkwNTc1NzY0fDA&ixlib=rb-4.1.0&q=85"
GALLERY_2 = "https://images.unsplash.com/photo-1709004915865-38bc70f4cb78?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA2OTV8MHwxfHNlYXJjaHwzfHxkcmFtYXRpYyUyMGJsYWNrJTIwbWFsZSUyMGFjdG9yJTIwcG9ydHJhaXR8ZW58MHx8fHwxNzkwNTc1NzY0fDA&ixlib=rb-4.1.0&q=85"
GALLERY_3 = "https://images.unsplash.com/photo-1565884280295-98eb83e41c65?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA2OTV8MHwxfHNlYXJjaHwxfHxkcmFtYXRpYyUyMGJsYWNrJTIwbWFsZSUyMGFjdG9yJTIwcG9ydHJhaXR8ZW58MHx8fHwxNzkwNTc1NzY0fDA&ixlib=rb-4.1.0&q=85"
MOOD_1 = "https://images.unsplash.com/photo-1691491918178-8a2e68b44919?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDQ2MzR8MHwxfHNlYXJjaHwzfHxmaWxtJTIwc2V0JTIwYmVoaW5kJTIwc2NlbmVzJTIwZGFya3xlbnwwfHx8fDE3OTA1NzU3NjR8MA&ixlib=rb-4.1.0&q=85"
MOOD_2 = "https://images.unsplash.com/photo-1728022038090-8ab88f8339bf?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDQ2MzR8MHwxfHNlYXJjaHwyfHxmaWxtJTIwc2V0JTIwYmVoaW5kJTIwc2NlbmVzJTIwZGFya3xlbnwwfHx8fDE3OTA1NzU3NjR8MA&ixlib=rb-4.1.0&q=85"
MOOD_3 = "https://images.unsplash.com/photo-1632187981988-40f3cbaeef5e?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDQ2MzR8MHwxfHNlYXJjaHw0fHxmaWxtJTIwc2V0JTIwYmVoaW5kJTIwc2NlbmVzJTIwZGFya3xlbnwwfHx8fDE3OTA1NzU3NjR8MA&ixlib=rb-4.1.0&q=85"

DEFAULT_CONTENT: Dict[str, Any] = {
    "name": "Exauce Baleke",
    "role_line": "Acteur - Scenariste",
    "location_line": "Goma - Kinshasa, RDC",
    "intro": "Du theatre de rue de Goma aux plateaux de Kinshasa, je construis des personnages avec le corps, la voix et la memoire de ceux qui m'ont precede.",
    "bio": "Forme au combat scenique et a la boxe, je passe de l'ecriture au plateau avec la meme exigence : des histoires enracinees, des corps qui parlent. Quatre langues, plusieurs accents, une seule ambition - porter le recit congolais sur tous les ecrans.",
    "hero_actor_image": HERO_ACTOR,
    "hero_scenario_image": HERO_SCREENWRITER,
    "portrait_main": HERO_ACTOR,
    "demo_reel_url": "https://www.youtube.com/watch?v=aqz-KE-bpKQ",
    "gallery": [
        {"url": HERO_ACTOR, "label": "Portrait neutre"},
        {"url": GALLERY_1, "label": "Sourire"},
        {"url": GALLERY_2, "label": "Plein pied"},
        {"url": GALLERY_3, "label": "En personnage"},
    ],
    "specs": {
        "Mensurations": [["Taille", "1m82"], ["Poids", "78 kg"], ["Tour de poitrine", "102 cm"], ["Pointure", "44"]],
        "Apparence": [["Yeux", "Marron fonce"], ["Cheveux", "Noirs, courts"], ["Teint", "Fonce"], ["Barbe", "Oui, modulable"]],
        "Langues": [["Lingala", "Langue maternelle"], ["Swahili", "Langue maternelle"], ["Francais", "Courant"], ["Anglais", "Courant"]],
        "Accents": [["Congolais", "Natif"], ["Nigerian", "Confirme"], ["Rwandais", "Confirme"], ["Francais international", "Confirme"]],
        "Skills": [["Boxe", "Confirme"], ["Combat scenique", "Confirme"], ["Danse", "Ndombolo, afrobeat"], ["Moto", "Conduite confirmee"], ["Chant", "Baryton"]],
        "Mobilite": [["Base", "Goma / Kinshasa"], ["Passeport", "Valide"], ["Disponibilite", "Internationale"]],
    },
    "links": {
        "whatsapp": "243990604665",
        "email": "casting@exauce-baleke.com",
        "instagram": "https://instagram.com/",
        "imdb": "https://imdb.com/",
    },
    "cv_pdf": "",
}


class ContentUpdate(BaseModel):
    data: Dict[str, Any]


async def get_content():
    cached = _cache_get("content")
    if cached is not None:
        return cached
    doc = await db.content.find_one({"key": "main"})
    data = doc.get("data", {}) if doc else {}
    return _cache_set("content", {**DEFAULT_CONTENT, **data})


async def get_scenarios():
    cached = _cache_get("scenarios")
    if cached is not None:
        return cached
    rows = await db.scenarios.find({}, {"_id": 0}).sort([("order", 1), ("created_at", 1)]).to_list(200)
    return _cache_set("scenarios", rows)


@api_router.get("/content")
async def content_endpoint(request: Request, response: Response):
    return _conditional_json(request, response, await get_content())


@api_router.put("/content")
async def update_content(update: ContentUpdate, user: dict = Depends(get_current_user)):
    await db.content.update_one(
        {"key": "main"},
        {"$set": {"data": update.data, "updated_at": datetime.now(timezone.utc).isoformat()}},
        upsert=True,
    )
    _CACHE.clear()
    return {"ok": True}


# ---------- Scenarios ----------
class ScenarioIn(BaseModel):
    title: str
    genre: str = ""
    format: str = ""
    status: str = ""
    pitch: str = ""
    synopsis: str = ""
    note_intention: str = ""
    poster: str = ""
    images: List[str] = []
    treatment_pdf: str = ""
    order: int = 0


@api_router.get("/scenarios")
async def list_scenarios(request: Request, response: Response):
    return _conditional_json(request, response, await get_scenarios())


@api_router.post("/scenarios", status_code=201)
async def create_scenario(input: ScenarioIn, user: dict = Depends(get_current_user)):
    doc = input.model_dump()
    doc["id"] = str(uuid.uuid4())
    doc["created_at"] = datetime.now(timezone.utc).isoformat()
    await db.scenarios.insert_one(doc)
    _CACHE.pop("scenarios", None)
    doc.pop("_id", None)
    return doc


@api_router.put("/scenarios/{sid}")
async def update_scenario(sid: str, input: ScenarioIn, user: dict = Depends(get_current_user)):
    res = await db.scenarios.update_one({"id": sid}, {"$set": input.model_dump()})
    _CACHE.pop("scenarios", None)
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Scenario introuvable")
    return await db.scenarios.find_one({"id": sid}, {"_id": 0})


@api_router.delete("/scenarios/{sid}")
async def delete_scenario(sid: str, user: dict = Depends(get_current_user)):
    res = await db.scenarios.delete_one({"id": sid})
    _CACHE.pop("scenarios", None)
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Scenario introuvable")
    return {"ok": True}


# ---------- Uploads ----------
ALLOWED_UPLOADS = {
    "jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png",
    "webp": "image/webp", "gif": "image/gif", "pdf": "application/pdf",
}
MAX_UPLOAD = 12 * 1024 * 1024
THUMB_WIDTHS = (200, 400, 500, 600, 800, 1000, 1200, 1600)
_THUMBS: "OrderedDict[tuple, tuple]" = OrderedDict()
FILE_HEADERS = {"Cache-Control": "public, max-age=31536000, immutable", "X-Content-Type-Options": "nosniff"}


def _downscale(data: bytes, ext: str, max_side: int = 2400) -> bytes:
    """Limite les photos envoyees a 2400 px pour economiser stockage et bande passante."""
    try:
        im = ImageOps.exif_transpose(Image.open(io.BytesIO(data)))
        if max(im.size) <= max_side and len(data) < 1_500_000:
            return data
        im.thumbnail((max_side, max_side))
        buf = io.BytesIO()
        if ext in ("jpg", "jpeg"):
            im.convert("RGB").save(buf, "JPEG", quality=85, optimize=True, progressive=True)
        elif ext == "png":
            im.save(buf, "PNG", optimize=True)
        else:
            im.save(buf, "WEBP", quality=85)
        return buf.getvalue()
    except Exception:
        return data


def _resize_webp(data: bytes, width: int):
    im = ImageOps.exif_transpose(Image.open(io.BytesIO(data)))
    if im.width <= width:
        return None
    im = im.resize((width, round(im.height * width / im.width)), Image.LANCZOS)
    if im.mode not in ("RGB", "RGBA"):
        im = im.convert("RGB")
    buf = io.BytesIO()
    im.save(buf, "WEBP", quality=78, method=4)
    return buf.getvalue()


@api_router.post("/upload")
async def upload(file: UploadFile = File(...), user: dict = Depends(get_current_user)):
    name = file.filename or ""
    ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
    if ext not in ALLOWED_UPLOADS:
        raise HTTPException(status_code=400, detail="Format non autorise (jpg, png, webp, gif, pdf).")
    data = await file.read(MAX_UPLOAD + 1)
    if len(data) > MAX_UPLOAD:
        raise HTTPException(status_code=413, detail="Fichier trop lourd (12 Mo maximum).")
    ctype = ALLOWED_UPLOADS[ext]
    if ctype.startswith("image/") and ext != "gif":
        data = await run_in_threadpool(_downscale, data, ext)
    path = f"{APP_NAME}/uploads/{user['_id']}/{uuid.uuid4()}.{ext}"
    result = await run_in_threadpool(put_object, path, data, ctype)
    await db.files.insert_one({
        "id": str(uuid.uuid4()),
        "storage_path": result["path"],
        "original_filename": name,
        "content_type": ctype,
        "size": result.get("size", len(data)),
        "is_deleted": False,
        "created_at": datetime.now(timezone.utc).isoformat(),
    })
    return {"path": result["path"]}


@api_router.get("/files/{path:path}")
async def download_file(path: str, w: int = 0):
    record = await db.files.find_one({"storage_path": path, "is_deleted": False})
    if not record:
        raise HTTPException(status_code=404, detail="File not found")
    ctype = record.get("content_type") or "application/octet-stream"
    try:
        if w in THUMB_WIDTHS and ctype.startswith("image/") and ctype != "image/gif":
            key = (path, w)
            if key in _THUMBS:
                _THUMBS.move_to_end(key)
                data, ctype = _THUMBS[key]
            else:
                raw, _ = await run_in_threadpool(get_object, path)
                small = await run_in_threadpool(_resize_webp, raw, w)
                data, ctype = (small, "image/webp") if small else (raw, ctype)
                _THUMBS[key] = (data, ctype)
                while len(_THUMBS) > 80:
                    _THUMBS.popitem(last=False)
        else:
            data, stored = await run_in_threadpool(get_object, path)
            ctype = record.get("content_type") or stored
    except Exception:
        raise HTTPException(status_code=404, detail="File not found")
    return Response(content=data, media_type=ctype, headers=FILE_HEADERS)


# ---------- AI (GPT 5.4 Mini) ----------
LLM_PROVIDER, LLM_MODEL = "openai", "gpt-5.4-mini"


def make_chat(session_id: str, system_message: str) -> LlmChat:
    return LlmChat(
        api_key=os.environ["EMERGENT_LLM_KEY"],
        session_id=session_id,
        system_message=system_message,
    ).with_model(LLM_PROVIDER, LLM_MODEL)


async def sse_stream(chat: LlmChat, prompt: str, on_done=None):
    # The currently published Python SDK exposes send_message(), while the old
    # project dependency expected a streaming API. We keep the SSE contract for
    # the frontend by sending the completed response as one delta.
    full: List[str] = []
    try:
        result = await chat.send_message(UserMessage(text=prompt))
        full.append(result or "")
        yield f"data: {json.dumps({'delta': result or ''})}\n\n"
    except Exception as e:
        logger.error(f"LLM stream error: {e}")
        yield f"data: {json.dumps({'delta': ''})}\n\n"
    yield "data: [DONE]\n\n"
    if on_done:
        try:
            await on_done("".join(full))
        except Exception as e:
            logger.error(f"Chat history store failed: {e}")


SSE_HEADERS = {"Cache-Control": "no-cache", "X-Accel-Buffering": "no"}


class ImproveInput(BaseModel):
    field: str
    text: str = Field(default="", max_length=6000)
    title: str = Field(default="", max_length=200)


@api_router.post("/ai/improve")
async def ai_improve(input: ImproveInput, user: dict = Depends(get_current_user)):
    system = (
        "Tu es un script doctor et conseiller litteraire francophone, specialiste du cinema africain. "
        "Tu reecris le texte fourni pour le rendre plus percutant, cinematographique et vendeur, en francais. "
        "Tu reponds uniquement avec le texte retravaille, sans preambule, sans guillemets, sans commentaire."
    )
    label = input.field or "texte"
    if input.text.strip():
        prompt = f"Projet : {input.title or 'sans titre'}\nType de texte : {label}\n\nTexte a ameliorer :\n{input.text}"
    else:
        prompt = f"Ecris un(e) {label} percutant(e) pour le projet « {input.title or 'sans titre'} »."
    chat = make_chat(f"improve-{user['_id']}-{uuid.uuid4()}", system)
    return StreamingResponse(sse_stream(chat, prompt), media_type="text/event-stream", headers=SSE_HEADERS)


class ChatInput(BaseModel):
    session_id: str = Field(min_length=6, max_length=80)
    message: str = Field(min_length=1, max_length=600)


def build_chat_system(content: dict, scenarios: list) -> str:
    specs = content.get("specs") or {}
    specs_txt = "; ".join(
        f"{g} : " + ", ".join(f"{k} {v}" for k, v in rows) for g, rows in specs.items()
    )
    scen_txt = "\n".join(
        f"- {s.get('title')} ({s.get('genre')}, {s.get('format')}, {s.get('status')}) : {s.get('pitch', '')}"
        for s in scenarios
    )
    links = content.get("links") or {}
    return (
        f"Tu es l'assistant virtuel du site officiel de {content.get('name')}, acteur et scenariste base a "
        f"{content.get('location_line')}. Tu reponds en francais, de facon concise et chaleureuse, aux "
        "directeurs de casting, realisateurs et producteurs. "
        f"Profil : {content.get('intro', '')} {content.get('bio', '')} "
        f"Caracteristiques : {specs_txt}. "
        f"Projets de scenarios :\n{scen_txt}\n"
        f"Pour toute demande concrete (booking, traitement complet, lecture de scenario), oriente vers WhatsApp : "
        f"+{links.get('whatsapp', '243990604665')} ou l'email {links.get('email', '')}. "
        "Ne reponds qu'aux questions liees a l'artiste, a sa carriere et a ses projets. Maximum 120 mots."
    )


@api_router.post("/chat")
async def public_chat(input: ChatInput, request: Request):
    rate_limit(request, "chat", 15, 600)
    if not input.message.strip():
        raise HTTPException(status_code=400, detail="Message vide")
    content = await get_content()
    scenarios = await get_scenarios()
    system = build_chat_system(content, scenarios)
    now = datetime.now(timezone.utc).isoformat()
    await db.chat_messages.insert_one(
        {"session_id": input.session_id, "role": "user", "content": input.message, "created_at": now}
    )
    history = await db.chat_messages.find({"session_id": input.session_id}, {"_id": 0}).sort("created_at", -1).to_list(8)
    history.reverse()
    hist_txt = "\n".join(
        ("Visiteur : " if m["role"] == "user" else "Assistant : ") + m["content"] for m in history
    )
    prompt = f"{hist_txt}\nAssistant :" if hist_txt else input.message
    chat = make_chat(f"visitor-{input.session_id}-{uuid.uuid4()}", system)

    async def store(answer: str):
        await db.chat_messages.insert_one(
            {
                "session_id": input.session_id,
                "role": "assistant",
                "content": answer,
                "created_at": datetime.now(timezone.utc).isoformat(),
            }
        )

    return StreamingResponse(sse_stream(chat, prompt, on_done=store), media_type="text/event-stream", headers=SSE_HEADERS)


# ---------- Misc ----------
@api_router.get("/")
async def root():
    return {"message": "Exauce Baleke — Acteur & Scenariste API"}


SEED_SCENARIOS = [
    {
        "id": str(uuid.uuid4()),
        "title": "Les Cendres du Kivu",
        "genre": "Drame historique",
        "format": "Long metrage - 105 min",
        "status": "En developpement",
        "pitch": "Apres l'eruption du Nyiragongo, un jeune guide doit choisir entre sauver sa famille ou les archives cachees qui pourraient faire trembler toute la region.",
        "synopsis": "Goma, quelques jours apres l'eruption. Faustin, guide de volcan au chomage, decouvre dans les decombres de la maison familiale une mallette d'archives appartenant a son pere, ancien notaire. Ces documents compromettent de puissants notables de la region. Traque, il traverse la ville en reconstruction pour rejoindre sa femme et sa fille refugiees a Sake, tandis que la lave figee porte encore la chaleur des secrets qu'elle a reveles. Un choix s'impose : detruire la mallette et vivre, ou la livrer et risquer tout.",
        "note_intention": "Filmer Goma comme un personnage : la lave noire, la poussiere, la lumiere rasante du matin. Un recit de transmission ou la memoire d'un pere devient l'arme d'un fils.",
        "poster": MOOD_1,
        "images": [MOOD_2, GALLERY_2, HERO_SCREENWRITER],
        "treatment_pdf": "",
        "order": 1,
        "created_at": datetime.now(timezone.utc).isoformat(),
    },
    {
        "id": str(uuid.uuid4()),
        "title": "Kin la Nuit",
        "genre": "Thriller",
        "format": "Serie - 8 x 52 min",
        "status": "En ecriture",
        "pitch": "Une chauffeuse de taxi nocturne devient l'oreille de toute la ville - jusqu'a la course de trop.",
        "synopsis": "Chaque nuit, Divine conduit son taxi dans Kinshasa et recueille les confidences de ses passagers : ministres, musiciens, truands, amants. Quand une passagere disparait apres lui avoir confie une preuve de corruption, Divine devient a la fois temoin et cible. De la Gombe a la cite, elle navigue entre les reseaux qui gouvernent la nuit, aidee d'un journaliste radiophonique insomniac. Chaque episode est une course ; chaque course rapproche la verite - et le danger.",
        "note_intention": "La nuit kinoise comme un personnage : neons, embouteillages, rumba lointaine. Une heroine silencieuse qui ecoute ce que la ville n'ose pas dire.",
        "poster": MOOD_2,
        "images": [MOOD_3, GALLERY_1, MOOD_1],
        "treatment_pdf": "",
        "order": 2,
        "created_at": datetime.now(timezone.utc).isoformat(),
    },
    {
        "id": str(uuid.uuid4()),
        "title": "Le Dernier Round",
        "genre": "Drame sportif",
        "format": "Long metrage - 90 min",
        "status": "Pitch pret",
        "pitch": "Un ancien champion de boxe de Goma entraine en secret la fille de son rival disparu sur le ring.",
        "synopsis": "Ex-champion devenu entraineur de rue, Muhindo a jure de ne plus monter dans un gymnase depuis la mort de son rival et ami, il y a quinze ans. Quand Amina, la fille de celui-ci, lui demande de la preparer pour le championnat national, il refuse - puis cede. L'entrainement devient un face-a-face avec le passe : la nuit du drame, les dettes, les promesses brisees. A quelques semaines du combat, la verite eclate et menace de briser ce qu'ils viennent de reconstruire.",
        "note_intention": "La boxe comme langage du deuil et du pardon. Des corps filmes au plus pres, la sueur et la poussiere, entre documentaire et melodrame.",
        "poster": MOOD_3,
        "images": [GALLERY_3, MOOD_1, HERO_SCREENWRITER],
        "treatment_pdf": "",
        "order": 3,
        "created_at": datetime.now(timezone.utc).isoformat(),
    },
    {
        "id": str(uuid.uuid4()),
        "title": "Sous le Volcan",
        "genre": "Drame",
        "format": "Court metrage - 20 min",
        "status": "Termine",
        "pitch": "Deux freres se retrouvent pour enterrer leur pere au pied du volcan qui a avale leur maison d'enfance.",
        "synopsis": "Alain est reste a Goma. Patient est parti pour Bruxelles. La mort de leur pere les oblige a se retrouver et a remonter ensemble, une derniere fois, la piste qui mene a l'ancienne maison, ensevelie sous la coulee. En chemin, les reproches remontent comme la chaleur du sol. Au sommet, face au cratere, les deux freres decouvrent ce que leur pere leur a laisse : pas un heritage, mais un itineraire.",
        "note_intention": "Un film de marche et de silence. Le volcan comme metaphore de ce qui gronde sous les familles - et finit parfois par les purifier.",
        "poster": HERO_SCREENWRITER,
        "images": [MOOD_3, MOOD_2, GALLERY_2],
        "treatment_pdf": "",
        "order": 4,
        "created_at": datetime.now(timezone.utc).isoformat(),
    },
]


async def seed_admin():
    admin_email = (os.environ.get("ADMIN_EMAIL") or "").strip().lower()
    admin_password = os.environ.get("ADMIN_PASSWORD") or ""
    if not admin_email or len(admin_password) < 10:
        raise RuntimeError("ADMIN_EMAIL et ADMIN_PASSWORD (10 caracteres minimum) doivent etre definis dans .env")
    existing = await db.users.find_one({"email": admin_email})
    if existing is None:
        await db.users.insert_one({
            "_id": str(uuid.uuid4()),
            "email": admin_email,
            "password_hash": hash_password(admin_password),
            "name": "Admin",
            "role": "admin",
            "created_at": datetime.now(timezone.utc).isoformat(),
        })
        logger.info("Admin user seeded")
    elif not verify_password(admin_password, existing["password_hash"]):
        await db.users.update_one({"email": admin_email}, {"$set": {"password_hash": hash_password(admin_password)}})
        logger.info("Admin password reconciled")


@app.on_event("startup")
async def startup():
    await db.users.create_index("email", unique=True)
    await db.login_attempts.create_index("identifier")
    await db.chat_messages.create_index([("session_id", 1), ("created_at", -1)])
    await db.files.create_index("storage_path")
    await db.scenarios.create_index([("order", 1), ("created_at", 1)])
    if len(os.environ.get("JWT_SECRET", "")) < 32:
        raise RuntimeError("JWT_SECRET doit contenir au moins 32 caracteres")
    try:
        init_storage()
        logger.info("Storage initialized")
    except Exception as e:
        logger.error(f"Storage init failed: {e}")
    await seed_admin()
    if await db.scenarios.count_documents({}) == 0:
        await db.scenarios.insert_many(SEED_SCENARIOS)
        logger.info("Sample scenarios seeded")


app.include_router(api_router)

_origins = [o for o in [os.environ.get("FRONTEND_URL"), "http://localhost:3000"] if o]
app.add_middleware(
    CORSMiddleware,
    allow_origins=_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization"],
)
app.add_middleware(GZipMiddleware, minimum_size=600)


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
